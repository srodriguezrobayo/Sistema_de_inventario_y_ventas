const express = require('express');
const router = express.Router();
const productosController = require('../controllers/productosController');

router.get('/', productosController.listarProductos);
router.get('/alertas/reabastecimiento', productosController.obtenerAlertasStock);

module.exports = router;