// Petición AJAX para obtener el catálogo de inventario desde la vista
async function cargarProductos() {
  try {
    const response = await fetch('http://localhost:3000/api/productos');
    const { data } = await response.json();
    
    const tabla = document.getElementById('tabla-productos');
    tabla.innerHTML = data.map(prod => `
      <tr>
        <td>${prod.codigo_barras}</td>
        <td>${prod.nombre}</td>
        <td>${prod.stock_actual}</td>
        <td>$${prod.precio_venta}</td>
      </tr>
    `).join('');
  } catch (error) {
    console.error('Error al cargar productos:', error);
  }
}

document.addEventListener('DOMContentLoaded', cargarProductos);