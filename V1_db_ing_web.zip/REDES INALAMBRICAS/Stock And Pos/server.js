const express = require('express');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// ... otros middlewares
app.use('/api/auth', require('./routes/authRoutes'));
// ...

// Servir la carpeta 'views' como archivos estáticos (HTML/CSS/JS)
app.use(express.static(path.join(__dirname, 'views')));

// Rutas de la API
app.use('/api/productos', require('./routes/productosRoutes'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor MVC ejecutándose en http://localhost:${PORT}`);
});