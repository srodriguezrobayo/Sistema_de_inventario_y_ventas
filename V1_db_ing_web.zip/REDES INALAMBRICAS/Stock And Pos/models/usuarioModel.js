const db = require('../config/db');

const Usuario = {
    // Buscar usuario por correo electrónico
    buscarPorEmail: async (email) => {
        const [filas] = await db.query('SELECT * FROM usuarios WHERE email = ?', [email]);
        return filas[0];
    }
};

module.exports = Usuario;