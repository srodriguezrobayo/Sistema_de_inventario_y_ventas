const db = require('../config/db');

const Producto = {
  // Obtener todos los productos
  obtenerTodos: async () => {
    const [rows] = await db.query('SELECT * FROM productos');
    return rows;
  },

  // Obtener productos en stock mínimo (para motor de alertas)
  obtenerParaReabastecimiento: async () => {
    const [rows] = await db.query(
      'SELECT * FROM productos WHERE stock_actual <= stock_minimo_dinamico'
    );
    return rows;
  },

  // Disminuir stock tras una venta
  actualizarStock: async (id, cantidad) => {
    const [result] = await db.query(
      'UPDATE productos SET stock_actual = stock_actual - ? WHERE id = ?',
      [cantidad, id]
    );
    return result;
  }
};

module.exports = Producto;