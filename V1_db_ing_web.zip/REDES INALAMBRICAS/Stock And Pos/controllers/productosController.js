const Producto = require('../models/productoModel');

exports.listarProductos = async (req, res) => {
  try {
    const productos = await Producto.obtenerTodos();
    res.status(200).json({ status: 'success', data: productos });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

exports.obtenerAlertasStock = async (req, res) => {
  try {
    const productosBajos = await Producto.obtenerParaReabastecimiento();
    res.status(200).json({ status: 'success', data: productosBajos });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};